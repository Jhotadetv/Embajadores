<?php
/**
 * Página de Gestión de Embajadores.
 */

if (!defined('ABSPATH')) {
    exit; // Salir si se accede directamente.
}

global $wpdb;
$table_embajadores = $wpdb->prefix . 'portal_embajadores';
$table_correos     = $wpdb->prefix . 'portal_embajadores_correos';

// Procesar formulario para añadir o actualizar embajador
if (isset($_POST['add_embajador_submit'], $_POST['add_embajador_nonce'])) {
    if (wp_verify_nonce($_POST['add_embajador_nonce'], 'add_embajador_action')) {
        $user_id    = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
        $sku        = isset($_POST['sku']) ? sanitize_text_field($_POST['sku']) : '';
        $cupon      = isset($_POST['cupon']) ? sanitize_text_field($_POST['cupon']) : '';
        $porcentaje = isset($_POST['porcentaje']) ? floatval($_POST['porcentaje']) : 0.0;
        $message_status = 'error';

        if ($user_id > 0) {
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$table_embajadores} WHERE user_id = %d",
                $user_id
            ));

            if ($exists) {
                $result = $wpdb->update(
                    $table_embajadores,
                    ['sku' => $sku, 'cupon' => $cupon, 'porcentaje' => $porcentaje],
                    ['user_id' => $user_id],
                    ['%s', '%s', '%f'],
                    ['%d']
                );
                if ($result !== false) {
                    $message_status = 'success_update';
                }
            } else {
                $result = $wpdb->insert(
                    $table_embajadores,
                    ['user_id' => $user_id, 'sku' => $sku, 'cupon' => $cupon, 'porcentaje' => $porcentaje],
                    ['%d', '%s', '%s', '%f']
                );
                if ($result !== false) {
                    $message_status = 'success_add';
                }
            }
        } else {
            $message_status = 'error_invalid_user_id';
        }

        wp_safe_redirect(add_query_arg('pe_status', $message_status, admin_url('admin.php?page=gestion-embajadores')));
        exit;
    } else {
        wp_safe_redirect(add_query_arg('pe_status', 'error_nonce', admin_url('admin.php?page=gestion-embajadores')));
        exit;
    }
}

// Procesar formulario para añadir nuevo correo autorizado
if (isset($_POST['add_correo_submit'], $_POST['add_correo_nonce'])) {
    if (wp_verify_nonce($_POST['add_correo_nonce'], 'add_correo_action')) {
        $email = isset($_POST['correo_nuevo']) ? sanitize_email($_POST['correo_nuevo']) : '';
        $message_status = 'error_correo';

        if (!empty($email) && is_email($email)) {
            $correo_exists = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$table_correos} WHERE email = %s",
                $email
            ));
            if (!$correo_exists) {
                $result = $wpdb->insert($table_correos, ['email' => $email], ['%s']);
                if ($result !== false) {
                    $message_status = 'success_correo_add';
                }
            } else {
                $message_status = 'error_correo_exists';
            }
        } else {
            $message_status = 'error_correo_invalid';
        }

        wp_safe_redirect(add_query_arg('pe_status', $message_status, admin_url('admin.php?page=gestion-embajadores')));
        exit;
    } else {
        wp_safe_redirect(add_query_arg('pe_status', 'error_nonce_correo', admin_url('admin.php?page=gestion-embajadores')));
        exit;
    }
}

// Mostrar notificaciones
if (isset($_GET['pe_status'])) {
    $status  = sanitize_key($_GET['pe_status']);
    $message = '';
    $type    = 'error';

    switch ($status) {
        case 'success_add':
            $message = __('Embajador añadido correctamente.', 'portal-embajadores');
            $type    = 'updated';
            break;
        case 'success_update':
            $message = __('Embajador actualizado correctamente.', 'portal-embajadores');
            $type    = 'updated';
            break;
        case 'error_invalid_user_id':
            $message = __('ID de usuario no válido.', 'portal-embajadores');
            break;
        case 'success_correo_add':
            $message = __('Correo autorizado añadido correctamente.', 'portal-embajadores');
            $type    = 'updated';
            break;
        case 'error_correo_exists':
            $message = __('Este correo ya está autorizado.', 'portal-embajadores');
            break;
        case 'error_correo_invalid':
            $message = __('El formato del correo no es válido.', 'portal-embajadores');
            break;
        case 'error_nonce':
        case 'error_nonce_correo':
            $message = __('Error de seguridad. Inténtalo de nuevo.', 'portal-embajadores');
            break;
        default:
            $message = __('Error al procesar la solicitud.', 'portal-embajadores');
    }

    if ($message) {
        echo '<div class="notice ' . esc_attr($type) . ' is-dismissible"><p>' . esc_html($message) . '</p></div>';
    }
}
?>

<div class="wrap">
    <h1><?php echo esc_html__('Gestión de Embajadores', 'portal-embajadores'); ?></h1>

    <hr>
    <h2><?php echo esc_html__('Añadir o Actualizar Embajador', 'portal-embajadores'); ?></h2>
    <form method="post" action="<?php echo esc_url(admin_url('admin.php?page=gestion-embajadores')); ?>">
        <?php wp_nonce_field('add_embajador_action', 'add_embajador_nonce'); ?>
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><label for="user_id"><?php echo esc_html__('ID Usuario (WordPress)', 'portal-embajadores'); ?></label></th>
                    <td>
                        <input type="number" id="user_id" name="user_id" class="regular-text" required />
                        <p class="description"><?php echo esc_html__('El ID del usuario de WordPress que será embajador.', 'portal-embajadores'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="sku"><?php echo esc_html__('SKU del Producto (Opcional)', 'portal-embajadores'); ?></label></th>
                    <td>
                        <input type="text" id="sku" name="sku" class="regular-text" />
                        <p class="description"><?php echo esc_html__('SKU del producto para comisión directa.', 'portal-embajadores'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="cupon"><?php echo esc_html__('Cupón de Descuento (Opcional)', 'portal-embajadores'); ?></label></th>
                    <td>
                        <input type="text" id="cupon" name="cupon" class="regular-text" />
                        <p class="description"><?php echo esc_html__('Código de cupón que el embajador promocionará.', 'portal-embajadores'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="porcentaje"><?php echo esc_html__('Porcentaje de Comisión (%)', 'portal-embajadores'); ?></label></th>
                    <td>
                        <input type="number" id="porcentaje" name="porcentaje" step="0.01" min="0" max="100" class="small-text" required />
                        <p class="description"><?php echo esc_html__('Por ejemplo, 10.5 para un 10.5%.', 'portal-embajadores'); ?></p>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php submit_button(__('Guardar Embajador', 'portal-embajadores'), 'primary', 'add_embajador_submit'); ?>
    </form>

    <hr>
    <h2><?php echo esc_html__('Correos Autorizados para ser Embajadores', 'portal-embajadores'); ?></h2>
    <p><?php echo esc_html__('Los usuarios con estos correos recibirán automáticamente el rol "Embajador".', 'portal-embajadores'); ?></p>
    <form method="post" action="<?php echo esc_url(admin_url('admin.php?page=gestion-embajadores')); ?>">
        <?php wp_nonce_field('add_correo_action', 'add_correo_nonce'); ?>
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><label for="correo_nuevo"><?php echo esc_html__('Añadir Email Autorizado', 'portal-embajadores'); ?></label></th>
                    <td><input type="email" id="correo_nuevo" name="correo_nuevo" class="regular-text" required /></td>
                </tr>
            </tbody>
        </table>
        <?php submit_button(__('Añadir Correo', 'portal-embajadores'), 'secondary', 'add_correo_submit'); ?>
    </form>

    <h3><?php echo esc_html__('Correos Autorizados Registrados', 'portal-embajadores'); ?></h3>
    <?php $correos_autorizados = $wpdb->get_results("SELECT email FROM {$table_correos} ORDER BY email ASC"); ?>
    <?php if ($correos_autorizados) : ?>
        <ul>
            <?php foreach ($correos_autorizados as $c) : ?>
                <li><?php echo esc_html($c->email); ?></li>
            <?php endforeach; ?>
        </ul>
    <?php else : ?>
        <p><?php echo esc_html__('No hay correos autorizados aún.', 'portal-embajadores'); ?></p>
    <?php endif; ?>

    <hr>
    <h2><?php echo esc_html__('Listado de Embajadores Registrados', 'portal-embajadores'); ?></h2>
    <?php
    $lista = $wpdb->get_results(
        "SELECT e.user_id, e.sku, e.cupon, e.porcentaje, u.user_login, u.user_email, u.display_name
         FROM {$table_embajadores} e
         LEFT JOIN {$wpdb->users} u ON e.user_id = u.ID
         ORDER BY u.display_name ASC"
    );
    if ($lista) : ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php echo esc_html__('ID', 'portal-embajadores'); ?></th>
                    <th><?php echo esc_html__('Usuario', 'portal-embajadores'); ?></th>
                    <th><?php echo esc_html__('Email', 'portal-embajadores'); ?></th>
                    <th><?php echo esc_html__('SKU', 'portal-embajadores'); ?></th>
                    <th><?php echo esc_html__('Cupón', 'portal-embajadores'); ?></th>
                    <th><?php echo esc_html__('Comisión (%)', 'portal-embajadores'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($lista as $emb) : ?>
                    <tr>
                        <td><?php echo esc_html($emb->user_id); ?></td>
                        <td><?php echo esc_html($emb->display_name ?: $emb->user_login); ?></td>
                        <td><?php echo esc_html($emb->user_email); ?></td>
                        <td><?php echo esc_html($emb->sku ?: '-'); ?></td>
                        <td><?php echo esc_html($emb->cupon ?: '-'); ?></td>
                        <td><?php echo esc_html(number_format_i18n($emb->porcentaje, 2)); ?>%</td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else : ?>
        <p><?php echo esc_html__('No hay embajadores registrados.', 'portal-embajadores'); ?></p>
    <?php endif; ?>
</div>