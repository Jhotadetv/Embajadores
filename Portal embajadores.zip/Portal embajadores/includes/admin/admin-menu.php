<?php
/**
 * Manejo del menú de administración para el Portal de Embajadores.
 */

if (!defined('ABSPATH')) {
    exit; // Salir si se accede directamente.
}

add_action('admin_menu', 'portal_embajadores_crear_admin_menu');

/**
 * Crea el menú principal y los submenús para el plugin en el panel de administración.
 */
function portal_embajadores_crear_admin_menu() {
    // Menú Principal
    add_menu_page(
        __('Portal Embajadores', 'portal-embajadores'), // Título de la página
        __('Portal Embajadores', 'portal-embajadores'), // Título del menú
        'manage_options',                         // Capacidad requerida
        'gestion-embajadores',                    // Slug del menú
        'portal_embajadores_render_gestion_page', // Función que renderiza la página
        'dashicons-groups',                       // Icono del menú (cambiado a 'dashicons-groups' que es más semántico)
        56                                        // Posición en el menú
    );

    // Submenú: Gestión de Embajadores (puede ser el mismo que el principal o uno específico)
    // Si la página principal 'gestion-embajadores' ya es para la gestión, este submenú podría ser redundante
    // o renombrarse a 'Listado de Embajadores' o similar si la página principal es un dashboard.
    // Por ahora, lo mantendré como estaba implícito, pero es un punto a considerar.
    // add_submenu_page(
    // 'gestion-embajadores',
    // __('Gestionar Embajadores', 'portal-embajadores'),
    // __('Gestionar Embajadores', 'portal-embajadores'),
    // 'manage_options',
    // 'gestion-embajadores', // Mismo slug que el principal
    // 'portal_embajadores_render_gestion_page'
    // );

    // Submenú: Gestión de Pagos
    add_submenu_page(
        'gestion-embajadores',                    // Slug del menú padre
        __('Gestión de Pagos', 'portal-embajadores'), // Título de la página
        __('Gestión de Pagos', 'portal-embajadores'), // Título del menú
        'manage_options',                         // Capacidad requerida
        'pagos-embajadores',                      // Slug del submenú
        'portal_embajadores_render_pagos_page'    // Función que renderiza la página
    );

    // Submenú: Ajustes API
    add_submenu_page(
        'gestion-embajadores',                    // Slug del menú padre
        __('Ajustes API', 'portal-embajadores'),      // Título de la página
        __('Ajustes API', 'portal-embajadores'),      // Título del menú
        'manage_options',                         // Capacidad requerida
        'settings-embajadores',                   // Slug del submenú
        'portal_embajadores_render_api_settings_page' // Función que renderiza la página
    );
}

/**
 * Renderiza la página de Gestión de Embajadores.
 * Incluye el archivo que contiene el HTML y la lógica de la página.
 */
function portal_embajadores_render_gestion_page() {
    require_once plugin_dir_path(__FILE__) . 'embajadores.php';
}

/**
 * Renderiza la página de Gestión de Pagos.
 * Incluye el archivo que contiene el HTML y la lógica de la página.
 */
function portal_embajadores_render_pagos_page() {
    require_once plugin_dir_path(__FILE__) . 'pagos-embajadores.php';
}

/**
 * Renderiza la página de Ajustes API.
 * Incluye el archivo que contiene el HTML y la lógica de la página.
 */
function portal_embajadores_render_api_settings_page() {
    require_once plugin_dir_path(__FILE__) . 'settings-page.php';
}