<?php
/**
 * Página de Ajustes API para el Portal de Embajadores.
 */

if (!defined('ABSPATH')) {
    exit; // Salir si se accede directamente.
}

// Nombre de la opción en la base de datos
if (!defined('PORTAL_EMBAJADORES_SETTINGS_OPTION')) {
    define('PORTAL_EMBAJADORES_SETTINGS_OPTION', 'portal_embajadores_api_settings');
}

// Procesar el formulario de guardado
if (isset($_POST['submit']) && isset($_POST['portal_embajadores_settings_nonce'])) {
    if (wp_verify_nonce($_POST['portal_embajadores_settings_nonce'], 'portal_embajadores_settings_save_action')) {
        $settings_to_save = [
            'twitch_client_id'     => isset($_POST['twitch_client_id']) ? sanitize_text_field($_POST['twitch_client_id']) : '',
            'twitch_client_secret' => isset($_POST['twitch_client_secret']) ? sanitize_text_field($_POST['twitch_client_secret']) : '',
            'google_client_id'     => isset($_POST['google_client_id']) ? sanitize_text_field($_POST['google_client_id']) : '',
            'google_client_secret' => isset($_POST['google_client_secret']) ? sanitize_text_field($_POST['google_client_secret']) : '',
        ];

        update_option(PORTAL_EMBAJADORES_SETTINGS_OPTION, $settings_to_save);
        wp_safe_redirect(add_query_arg('pe_status', 'success_settings', admin_url('admin.php?page=settings-embajadores')));
        exit;
    } else {
        wp_safe_redirect(add_query_arg('pe_status', 'error_nonce_settings', admin_url('admin.php?page=settings-embajadores')));
        exit;
    }
}

// Mostrar notificaciones
if (isset($_GET['pe_status'])) {
    $status  = sanitize_key($_GET['pe_status']);
    $message = '';
    $type    = 'error';

    switch ($status) {
        case 'success_settings':
            $message = __('Ajustes guardados correctamente.', 'portal-embajadores');
            $type    = 'updated';
            break;
        case 'error_nonce_settings':
            $message = __('Error de seguridad. Inténtalo de nuevo.', 'portal-embajadores');
            break;
    }

    if ($message) {
        echo '<div class="notice ' . esc_attr($type) . ' is-dismissible"><p>' . esc_html($message) . '</p></div>'; }
}

// Obtener las opciones guardadas
$options = get_option(PORTAL_EMBAJADORES_SETTINGS_OPTION, []);

$twitch_client_id     = $options['twitch_client_id']     ?? '';
$twitch_client_secret = $options['twitch_client_secret'] ?? '';
$google_client_id     = $options['google_client_id']     ?? '';
$google_client_secret = $options['google_client_secret'] ?? '';
?>

<div class="wrap">
    <h1><?php echo esc_html__('Ajustes API - Portal Embajadores', 'portal-embajadores'); ?></h1>
    <p><?php echo esc_html__('Configura aquí las credenciales de API para las integraciones con servicios externos.', 'portal-embajadores'); ?></p>

    <form method="post" action="<?php echo esc_url(admin_url('admin.php?page=settings-embajadores')); ?>">
        <?php wp_nonce_field('portal_embajadores_settings_save_action', 'portal_embajadores_settings_nonce'); ?>

        <h2><?php echo esc_html__('Integración con Twitch', 'portal-embajadores'); ?></h2>
        <table class="form-table">
            <tr>
                <th><label for="twitch_client_id"><?php echo esc_html__('Twitch Client ID', 'portal-embajadores'); ?></label></th>
                <td><input type="text" id="twitch_client_id" name="twitch_client_id" value="<?php echo esc_attr($twitch_client_id); ?>" class="regular-text" required /></td>
            </tr>
            <tr>
                <th><label for="twitch_client_secret"><?php echo esc_html__('Twitch Client Secret', 'portal-embajadores'); ?></label></th>
                <td><input type="password" id="twitch_client_secret" name="twitch_client_secret" value="<?php echo esc_attr($twitch_client_secret); ?>" class="regular-text" placeholder="<?php echo esc_attr__('Dejar vacío para no cambiar', 'portal-embajadores'); ?>" /></td>
            </tr>
        </table>

        <h2><?php echo esc_html__('Integración con Google (YouTube)', 'portal-embajadores'); ?></h2>
        <table class="form-table">
            <tr>
                <th><label for="google_client_id"><?php echo esc_html__('Google Client ID', 'portal-embajadores'); ?></label></th>
                <td><input type="text" id="google_client_id" name="google_client_id" value="<?php echo esc_attr($google_client_id); ?>" class="regular-text" required /></td>
            </tr>
            <tr>
                <th><label for="google_client_secret"><?php echo esc_html__('Google Client Secret', 'portal-embajadores'); ?></label></th>
                <td><input type="password" id="google_client_secret" name="google_client_secret" value="<?php echo esc_attr($google_client_secret); ?>" class="regular-text" placeholder="<?php echo esc_attr__('Dejar vacío para no cambiar', 'portal-embajadores'); ?>" /></td>
            </tr>
        </table>

        <?php submit_button(__('Guardar Ajustes', 'portal-embajadores')); ?>
    </form>
</div>