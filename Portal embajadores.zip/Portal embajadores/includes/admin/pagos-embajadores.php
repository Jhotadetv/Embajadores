<?php
/**
 * Página de Gestión de Pagos a Embajadores.
 */

if (!defined('ABSPATH')) {
    exit; // Salir si se accede directamente.
}

global $wpdb;
$table_embajadores = $wpdb->prefix . 'portal_embajadores';
$table_ventas      = $wpdb->prefix . 'portal_embajadores_ventas';

// Procesar acción de marcar como pagado
if (isset($_POST['marcar_pagado_submit'], $_POST['embajador_db_id'], $_POST['marcar_pago_nonce'])) {
    $embajador_db_id = intval($_POST['embajador_db_id']);
    if (wp_verify_nonce($_POST['marcar_pago_nonce'], 'marcar_pago_action_' . $embajador_db_id)) {
        $message_status = 'error_pago';
        if ($embajador_db_id > 0) {
            $result = $wpdb->update(
                $table_embajadores,
                ['pagado' => 1],
                ['id' => $embajador_db_id],
                ['%d'],
                ['%d']
            );
            if ($result !== false) {
                $message_status = 'success_pago';
            }
        }
        wp_safe_redirect(add_query_arg('pe_status', $message_status, admin_url('admin.php?page=pagos-embajadores')));
        exit;
    } else {
        wp_safe_redirect(add_query_arg('pe_status', 'error_nonce_pago', admin_url('admin.php?page=pagos-embajadores')));
        exit;
    }
}

// Mostrar notificaciones
if (isset($_GET['pe_status'])) {
    $status  = sanitize_key($_GET['pe_status']);
    $message = '';
    $type    = 'error';

    switch ($status) {
        case 'success_pago':
            $message = __('Pago marcado correctamente.', 'portal-embajadores');
            $type    = 'updated';
            break;
        case 'error_pago':
            $message = __('Error al marcar el pago.', 'portal-embajadores');
            break;
        case 'error_nonce_pago':
            $message = __('Error de seguridad. Inténtalo de nuevo.', 'portal-embajadores');
            break;
    }

    if ($message) {
        echo '<div class="notice ' . esc_attr($type) . ' is-dismissible"><p>' . esc_html($message) . '</p></div>';
    }
}

// Obtener embajadores con pagos pendientes
$embajadores_pendientes = $wpdb->get_results(
    $wpdb->prepare(
        "SELECT e.id AS embajador_db_id, e.user_id, e.sku, e.cupon, e.porcentaje, u.display_name, u.user_email,
         SUM(v.importe_comision) AS total_comision_pendiente
         FROM {$table_embajadores} e
         JOIN {$wpdb->users} u ON e.user_id = u.ID
         LEFT JOIN {$table_ventas} v ON e.user_id = v.embajador_id
         WHERE e.pagado = %d
         GROUP BY e.id, e.user_id, e.sku, e.cupon, e.porcentaje, u.display_name, u.user_email
         HAVING SUM(v.importe_comision) > 0
         ORDER BY u.display_name ASC",
        0
    )
);
?>
<div class="wrap">
    <h1><?php echo esc_html__('Gestión de Pagos a Embajadores', 'portal-embajadores'); ?></h1>
    <p><?php echo esc_html__('Esta sección muestra los embajadores que tienen comisiones pendientes de pago. Al "Marcar Pagado", se actualiza su estado.', 'portal-embajadores'); ?></p>

    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th><?php echo esc_html__('Embajador', 'portal-embajadores'); ?></th>
                <th><?php echo esc_html__('Email', 'portal-embajadores'); ?></th>
                <th><?php echo esc_html__('SKU', 'portal-embajadores'); ?></th>
                <th><?php echo esc_html__('Cupón', 'portal-embajadores'); ?></th>
                <th><?php echo esc_html__('Comisión (%)', 'portal-embajadores'); ?></th>
                <th><?php echo esc_html__('Total Pendiente (€)', 'portal-embajadores'); ?></th>
                <th><?php echo esc_html__('Acciones', 'portal-embajadores'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($embajadores_pendientes)) : ?>
                <tr><td colspan="7"><?php echo esc_html__('No hay pagos pendientes.', 'portal-embajadores'); ?></td></tr>
            <?php else: foreach ($embajadores_pendientes as $e): ?>
                <tr>
                    <td><?php echo esc_html($e->display_name ?: $e->user_id); ?></td>
                    <td><?php echo esc_html($e->user_email); ?></td>
                    <td><?php echo esc_html($e->sku ?: '-'); ?></td>
                    <td><?php echo esc_html($e->cupon ?: '-'); ?></td>
                    <td><?php echo esc_html(number_format_i18n($e->porcentaje, 2)); ?>%</td>
                    <td><?php echo esc_html(number_format_i18n($e->total_comision_pendiente, 2)); ?>€</td>
                    <td>
                        <form method="post" action="<?php echo esc_url(admin_url('admin.php?page=pagos-embajadores')); ?>">
                            <?php wp_nonce_field('marcar_pago_action_' . $e->embajador_db_id, 'marcar_pago_nonce'); ?>
                            <input type="hidden" name="embajador_db_id" value="<?php echo esc_attr($e->embajador_db_id); ?>">
                            <button type="submit" name="marcar_pagado_submit" class="button button-primary"><?php echo esc_html__('Marcar Pagado', 'portal-embajadores'); ?></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>