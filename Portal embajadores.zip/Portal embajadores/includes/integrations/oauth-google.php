<?php
/**
 * Manejo de la autenticación OAuth con Google.
 * VERSIÓN DE DIAGNÓSTICO FINAL - Muestra el progreso en pantalla.
 */

if (!defined('ABSPATH')) {
    exit;
}

use League\OAuth2\Client\Provider\Google;
use League\OAuth2\Client\Provider\Exception\IdentityProviderException;

add_action('init', 'portal_embajadores_iniciar_google_oauth_flow_debug', 5);

function portal_embajadores_iniciar_google_oauth_flow_debug() {
    // Solo actuar si es una petición de Google
    if (!isset($_GET['pe_oauth_provider']) || $_GET['pe_oauth_provider'] !== 'google') {
        return;
    }

    // Parte 1: Redirigir a Google (sabemos que esto funciona)
    if (!isset($_GET['code'])) {
        if (session_status() == PHP_SESSION_NONE) { session_start(['cookie_secure' => is_ssl(), 'cookie_httponly' => true, 'cookie_samesite' => 'Lax']); }
        $options = get_option('portal_embajadores_api_settings', []);
        if (empty($options['google_client_id']) || empty($options['google_client_secret'])) { echo "Error: Faltan las credenciales de Google."; exit; }
        
        $provider = new Google([
            'clientId'     => $options['google_client_id'],
            'clientSecret' => $options['google_client_secret'],
            'redirectUri'  => add_query_arg('pe_oauth_provider', 'google', home_url('/'))
        ]);
        $authorizationUrl = $provider->getAuthorizationUrl(['scope' => ['email', 'profile']]);
        $_SESSION['pe_oauth2state_google'] = $provider->getState();
        wp_redirect($authorizationUrl);
        exit;
    }

    // --- INICIO DE LA ZONA DE DIAGNÓSTICO ---
    // El código a partir de aquí solo se ejecuta cuando Google nos devuelve al sitio.
    
    echo "INICIO DE DIAGNÓSTICO...<br>";

    if (session_status() == PHP_SESSION_NONE) {
        session_start(['cookie_secure' => is_ssl(), 'cookie_httponly' => true, 'cookie_samesite' => 'Lax']);
    }
    
    // PASO 1: Comprobar el código de seguridad
    if (empty($_GET['state']) || empty($_SESSION['pe_oauth2state_google']) || $_GET['state'] !== $_SESSION['pe_oauth2state_google']) {
        echo "ERROR EN PASO 1: Fallo de seguridad (state/CSRF).";
        exit;
    }
    unset($_SESSION['pe_oauth2state_google']);
    echo "PASO 1 SUPERADO: Verificación de seguridad OK.<br>";

    // PASO 2: Intentar obtener el token
    try {
        $options = get_option('portal_embajadores_api_settings', []);
        if (empty($options['google_client_id']) || empty($options['google_client_secret'])) {
            echo "ERROR EN PASO 2: No se encontraron las credenciales para obtener el token.";
            exit;
        }

        $provider = new Google([
            'clientId'     => $options['google_client_id'],
            'clientSecret' => $options['google_client_secret'],
            'redirectUri'  => add_query_arg('pe_oauth_provider', 'google', home_url('/'))
        ]);
        
        echo "PASO 2 SUPERADO: Preparado para obtener el Token de Acceso.<br>";
        
        $accessToken = $provider->getAccessToken('authorization_code', [
            'code' => sanitize_text_field(wp_unslash($_GET['code']))
        ]);

        echo "PASO 3 SUPERADO: Token de Acceso obtenido de Google.<br>";

        $resourceOwner = $provider->getResourceOwner($accessToken);
        $email = $resourceOwner->getEmail();

        if (empty($email)) {
            echo "ERROR EN PASO 4: Google no devolvió un email.";
            exit;
        }

        echo "PASO 4 SUPERADO: Datos de Usuario Obtenidos. Email: " . esc_html($email) . "<br>";
        
        echo "<strong>DIAGNÓSTICO FINALIZADO CON ÉXITO.</strong><br>";
        echo "<p>Si ves este mensaje, significa que este archivo (oauth-google.php) funciona perfectamente y el problema reside en la función <code>portal_embajadores_oauth_login_or_register_user</code> del archivo <code>functions.php</code>.</p>";

        // Intentar llamar a la función final
        // portal_embajadores_oauth_login_or_register_user($email, $resourceOwner->getName(), $resourceOwner->getName(), '', 'google', $resourceOwner->toArray());

    } catch (Exception $e) {
        echo "ERROR CRÍTICO EN PASO 3: Excepción al comunicarse con Google.<br>";
        echo "Mensaje del error: " . esc_html($e->getMessage());
    }

    exit; // Detener el script aquí para poder ver todos los mensajes.
}

function portal_embajadores_get_google_login_url() {
    return add_query_arg('pe_oauth_provider', 'google', home_url('/'));
}