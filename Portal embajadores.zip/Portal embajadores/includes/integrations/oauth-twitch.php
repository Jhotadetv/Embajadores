<?php
/**
 * Manejo de la autenticación OAuth con Twitch.
 */

if (!defined('ABSPATH')) {
    exit; // Salir si se accede directamente.
}

// if (!class_exists('League\OAuth2\Client\Provider\GenericProvider')) {
//     return;
// }

use League\OAuth2\Client\Provider\GenericProvider; // Usado para Twitch
use League\OAuth2\Client\Provider\Exception\IdentityProviderException;

add_action('init', 'portal_embajadores_iniciar_twitch_oauth_flow', 5);

/**
 * Inicia el flujo de autenticación OAuth con Twitch si se detecta la solicitud.
 */
function portal_embajadores_iniciar_twitch_oauth_flow() {
    if (!isset($_GET['pe_oauth_provider']) || $_GET['pe_oauth_provider'] !== 'twitch') {
        return;
    }

    if (session_status() == PHP_SESSION_NONE) {
        session_start([
            'cookie_secure' => true,
            'cookie_httponly' => true,
            'cookie_samesite' => 'Lax'
        ]);
    }

    $options = get_option('portal_embajadores_api_settings', []);
    if (empty($options['twitch_client_id']) || empty($options['twitch_client_secret'])) {
        wp_die(
            esc_html__('Las credenciales de API de Twitch no están configuradas. Por favor, configúralas en el panel de ajustes del plugin Portal Embajadores.', 'portal-embajadores'),
            esc_html__('Error de Configuración de Twitch OAuth', 'portal-embajadores'),
            ['response' => 500]
        );
        return;
    }

    $redirect_uri = add_query_arg('pe_oauth_provider', 'twitch', remove_query_arg(['code', 'state', 'scope', 'error', 'error_description'], home_url('/')));

    try {
        $provider = new GenericProvider([
            'clientId'                => $options['twitch_client_id'],
            'clientSecret'            => $options['twitch_client_secret'],
            'redirectUri'             => $redirect_uri,
            'urlAuthorize'            => 'https://id.twitch.tv/oauth2/authorize',
            'urlAccessToken'          => 'https://id.twitch.tv/oauth2/token',
            'urlResourceOwnerDetails' => 'https://api.twitch.tv/helix/users', // Endpoint para obtener datos del usuario
        ]);
    } catch (Exception $e) {
        wp_die(
            esc_html__('Error al inicializar el proveedor OAuth de Twitch: ', 'portal-embajadores') . esc_html($e->getMessage()),
            esc_html__('Error de Twitch OAuth', 'portal-embajadores'),
            ['response' => 500]
        );
        return;
    }


    if (!isset($_GET['code'])) {
        $authorizationUrl = $provider->getAuthorizationUrl([
            'scope' => apply_filters('portal_embajadores_twitch_scopes', 'user:read:email'), // Scope para obtener el email
            // 'force_verify' => 'true' // Para forzar que el usuario siempre vea la pantalla de consentimiento de Twitch
        ]);
        $_SESSION['pe_oauth2state_twitch'] = $provider->getState();
        
        wp_redirect($authorizationUrl);
        exit;
    }

    if (empty($_GET['state']) || empty($_SESSION['pe_oauth2state_twitch']) || $_GET['state'] !== $_SESSION['pe_oauth2state_twitch']) {
        unset($_SESSION['pe_oauth2state_twitch']);
        wp_die(
            esc_html__('Estado de OAuth inválido. Esto podría ser un intento de CSRF. Por favor, intenta iniciar sesión de nuevo.', 'portal-embajadores'),
            esc_html__('Error de Seguridad de Twitch OAuth', 'portal-embajadores'),
            ['response' => 403]
        );
        return;
    }
    unset($_SESSION['pe_oauth2state_twitch']);

    if (isset($_GET['error'])) {
        $error_description = isset($_GET['error_description']) ? sanitize_text_field(wp_unslash($_GET['error_description'])) : esc_html__('Error desconocido.', 'portal-embajadores');
        wp_die(
            sprintf(
                esc_html__('Twitch devolvió un error: %s - %s', 'portal-embajadores'),
                esc_html(sanitize_text_field(wp_unslash($_GET['error']))),
                esc_html($error_description)
            ),
            esc_html__('Error de Twitch OAuth', 'portal-embajadores'),
            ['response' => 401]
        );
        return;
    }

    try {
        $accessToken = $provider->getAccessToken('authorization_code', [
            'code' => sanitize_text_field(wp_unslash($_GET['code']))
        ]);

        // Para Twitch, se necesita el Client-ID en la cabecera para las llamadas a Helix API
        $requestOptions = [
            'headers' => [
                'Client-ID' => $options['twitch_client_id'],
                'Authorization' => 'Bearer ' . $accessToken->getToken() // El token de acceso
            ]
        ];
        
        // El GenericProvider no tiene un método getResourceOwnerDetails que funcione directamente con Twitch Helix de forma estándar.
        // Se debe hacer una solicitud GET autenticada.
        $userResourceRequest = $provider->getAuthenticatedRequest(
            'GET',
            $provider->getResourceOwnerDetailsUrl($accessToken), // Esto es 'https://api.twitch.tv/helix/users'
            $accessToken,
            $requestOptions // Pasar las cabeceras aquí
        );
        
        $userResourceResponse = $provider->getParsedResponse($userResourceRequest);
        // La respuesta de /helix/users es un array 'data' que contiene un objeto de usuario.
        if (empty($userResourceResponse['data']) || empty($userResourceResponse['data'][0])) {
             wp_die(
                esc_html__('No se pudieron obtener los datos del usuario desde Twitch.', 'portal-embajadores'),
                esc_html__('Error de Twitch OAuth', 'portal-embajadores'),
                ['response' => 500]
            );
            return;
        }
        $userData = $userResourceResponse['data'][0]; // Primer usuario en la respuesta

        $email = $userData['email'] ?? null; // El email puede no estar verificado o ser privado
        $display_name = $userData['display_name'] ?? $userData['login']; // Nombre para mostrar
        $login_name = $userData['login']; // Nombre de usuario único de Twitch
        // $avatar_url = $userData['profile_image_url']; // Podrías guardar esto

        if (empty($email)) {
            // Twitch a veces no devuelve el email si no está verificado o si el scope no fue suficiente,
            // o si el usuario lo tiene como privado.
            // Podrías permitir el login usando el $login_name como un identificador único
            // y generar un email placeholder si tu sistema lo requiere estrictamente.
            // O pedir al usuario que establezca un email después.
            wp_die(
                esc_html__('No se pudo obtener la dirección de correo electrónico de Twitch. Asegúrate de que el permiso "user:read:email" fue concedido y tu email está verificado en Twitch.', 'portal-embajadores'),
                esc_html__('Error de Twitch OAuth', 'portal-embajadores'),
                ['response' => 400]
            );
            return;
        }

        // Loguear o registrar al usuario en WordPress
        portal_embajadores_oauth_login_or_register_user($email, $display_name, $display_name, '', 'twitch', $userData);
        exit;

    } catch (IdentityProviderException $e) {
        wp_die(
            esc_html__('Error al comunicarse con Twitch: ', 'portal-embajadores') . esc_html($e->getMessage()),
            esc_html__('Error de Twitch OAuth', 'portal-embajadores'),
            ['response' => 500]
        );
    } catch (Exception $e) {
        wp_die(
            esc_html__('Ocurrió un error inesperado durante el proceso de OAuth con Twitch: ', 'portal-embajadores') . esc_html($e->getMessage()),
            esc_html__('Error de Twitch OAuth', 'portal-embajadores'),
            ['response' => 500]
        );
    }
}

/**
 * Genera la URL para iniciar el login con Twitch.
 *
 * @return string URL de login.
 */
function portal_embajadores_get_twitch_login_url() {
    return add_query_arg('pe_oauth_provider', 'twitch', home_url('/'));
}