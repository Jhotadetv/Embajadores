<?php
/**
 * Funciones generales del plugin Portal de Embajadores.
 * VERSIÓN FINAL con lógica de login y asignación de rol unificada y reforzada.
 */

if (!defined('ABSPATH')) exit;

// Se mantiene 'user_register' para registros estándar desde el backend de WordPress.
add_action('user_register', 'portal_embajadores_asignar_rol_registro');
function portal_embajadores_asignar_rol_registro($user_id) {
    global $wpdb;
    $user_data = get_userdata($user_id);
    if (!$user_data) return;

    $user_email = $user_data->user_email;
    $table_correos_autorizados = $wpdb->prefix . 'portal_embajadores_correos';
    
    $autorizado = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$table_correos_autorizados} WHERE email = %s",
        $user_email
    ));

    if ($autorizado) {
        $user = new WP_User($user_id);
        if ($user->exists() && !in_array('embajador', (array)$user->roles)) {
            $user->add_role('embajador');
        }
    }
}

function portal_embajadores_registrar_rutas_api() {
    register_rest_route('portal_embajadores/v1', '/check_new_alert/(?P<user_id>\\d+)', [
        'methods' => 'GET',
        'callback' => 'portal_embajadores_callback_check_new_alert',
        'permission_callback' => '__return_true', // Abierto para que OBS pueda acceder.
    ]);
     register_rest_route('portal_embajadores/v1', '/trigger_test_alert/(?P<user_id>\\d+)', [
        'methods' => 'POST',
        'callback' => 'portal_embajadores_callback_trigger_test_alert',
        'permission_callback' => function ($request) {
            // Solo el usuario logueado puede probar sus propias alertas.
            return get_current_user_id() === (int) $request['user_id'];
        }
    ]);
}
add_action('rest_api_init', 'portal_embajadores_registrar_rutas_api');

function portal_embajadores_callback_check_new_alert(WP_REST_Request $request) {
    global $wpdb;
    $user_id = (int)$request['user_id'];
    $tabla_ventas = $wpdb->prefix . 'portal_embajadores_ventas';
    $venta = $wpdb->get_row($wpdb->prepare("SELECT id, importe_comision, sku_producto FROM {$tabla_ventas} WHERE embajador_id = %d AND alerta_mostrada = 0 ORDER BY fecha DESC LIMIT 1", $user_id));
    if ($venta) {
        $wpdb->update($tabla_ventas, ['alerta_mostrada' => 1], ['id' => $venta->id]);
        return new WP_REST_Response(['trigger_alert' => true, 'alert_data' => ['producto' => $venta->sku_producto ?: __('un producto', 'portal-embajadores'), 'comision' => number_format_i18n($venta->importe_comision, 2) . '€']]);
    }
    return new WP_REST_Response(['trigger_alert' => false]);
}

function portal_embajadores_callback_trigger_test_alert(WP_REST_Request $request) {
    global $wpdb;
    $user_id = (int)$request['user_id'];
    $table_ventas = $wpdb->prefix . 'portal_embajadores_ventas';
    $wpdb->insert($table_ventas, ['embajador_id' => $user_id, 'order_id' => 0, 'fecha' => current_time('mysql'), 'sku_producto' => 'PRODUCTO-DE-PRUEBA', 'cupon_usado' => 'CUPON-TEST', 'importe_total_venta' => 99.99, 'importe_comision' => 12.34, 'alerta_mostrada' => 0]);
    return new WP_REST_Response(['status' => 'success', 'message' => 'Test alert created.']);
}

add_action('woocommerce_order_status_completed', 'portal_embajadores_registrar_venta_woocommerce');
add_action('woocommerce_order_status_processing', 'portal_embajadores_registrar_venta_woocommerce');

function portal_embajadores_registrar_venta_woocommerce($order_id) {
    if (!$order = wc_get_order($order_id)) return;
    global $wpdb;
    $table_embajadores = $wpdb->prefix . 'portal_embajadores';
    $table_ventas = $wpdb->prefix . 'portal_embajadores_ventas';
    $embajador = null;
    foreach ($order->get_coupon_codes() as $cupon) {
        $embajador = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_embajadores} WHERE cupon=%s LIMIT 1", $cupon));
        if ($embajador) break;
    }
    if (!$embajador) {
        foreach ($order->get_items() as $item) {
            if ($product = $item->get_product()) {
                if ($sku = $product->get_sku()) {
                    $embajador = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_embajadores} WHERE sku=%s LIMIT 1", $sku));
                    if ($embajador) break;
                }
            }
        }
    }
    if (!$embajador) return;
    $subtotal = $order->get_subtotal();
    $comision = round($subtotal * $embajador->porcentaje / 100, 2);
    if (!$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table_ventas} WHERE embajador_id=%d AND order_id=%d", $embajador->user_id, $order_id))) {
        $wpdb->insert($table_ventas, ['embajador_id' => $embajador->user_id, 'order_id' => $order_id, 'fecha' => current_time('mysql'), 'sku_producto' => $embajador->sku, 'cupon_usado' => implode(', ', $order->get_coupon_codes()), 'importe_total_venta' => $order->get_total(), 'importe_comision' => $comision, 'alerta_mostrada' => 0]);
        $wpdb->update($table_embajadores, ['pagado' => 0], ['user_id' => $embajador->user_id]);
    }
}

/**
 * Función de Login/Registro UNIFICADA Y DEFINITIVA.
 */
function portal_embajadores_oauth_login_or_register_user($email, $display_name, $first_name = '', $last_name = '', $provider = 'unknown', $oauth_user_data = []) {
    ob_start();

    if (!is_email($email)) {
        wp_die(__('El email proporcionado no es válido.', 'portal-embajadores'));
    }

    $user = get_user_by('email', $email);

    if (!$user) {
        $username_base = sanitize_user(explode('@', $email)[0], true);
        $username = $username_base; $i = 1;
        while (username_exists($username)) { $username = $username_base . $i; $i++; }
        
        $user_id = wp_create_user($username, wp_generate_password(), $email);
        if (is_wp_error($user_id)) {
            wp_die(__('Error al crear el usuario: ', 'portal-embajadores') . esc_html($user_id->get_error_message()));
        }
        wp_update_user(['ID' => $user_id, 'display_name' => esc_html($display_name), 'first_name' => esc_html($first_name), 'last_name' => esc_html($last_name)]);
        update_user_meta($user_id, 'oauth_provider', $provider);
        $user = get_user_by('ID', $user_id);
    }
    
    if ($user && is_a($user, 'WP_User')) {
        if (!in_array('embajador', (array)$user->roles)) {
            global $wpdb;
            $table_correos_autorizados = $wpdb->prefix . 'portal_embajadores_correos';
            $autorizado = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table_correos_autorizados} WHERE email = %s", $email));
            
            if ($autorizado) {
                $user->add_role('embajador');
                // --- SOLUCIÓN: Forzar el refresco de los datos del usuario ---
                // Esto asegura que WordPress reconoce el nuevo rol inmediatamente.
                clean_user_cache($user->ID);
                $user = get_user_by('ID', $user->ID); 
            }
        }
        
        // --- VERIFICACIÓN FINAL ---
        // Antes de redirigir, confirmamos que el usuario tiene el rol necesario.
        if (!in_array('embajador', (array)$user->roles)) {
            ob_end_clean();
            wp_die('<div style="padding:20px; font-family: sans-serif; text-align: center;"><h3>Acceso Denegado</h3><p>Has iniciado sesión correctamente, pero tu cuenta con el email <strong>' . esc_html($email) . '</strong> no está autorizada como embajador.</p><p>Si crees que esto es un error, por favor, contacta con el administrador del sitio.</p></div>', 'Acceso No Autorizado', ['response' => 403]);
        }

        wp_set_current_user($user->ID, $user->user_login);
        wp_set_auth_cookie($user->ID, true, is_ssl());
        do_action('wp_login', $user->user_login, $user);
        
        $redirect_url = home_url('/perfil-embajador/');
        echo '<p>Redirigiendo...</p><script>window.location.href = "' . esc_url_raw($redirect_url) . '";</script>';
        ob_end_flush(); 
        exit;
    }
    
    wp_die(__('Ocurrió un error inesperado durante el login.', 'portal-embajadores'));
}

function portal_embajadores_login_buttons_shortcode() {
    ob_start();
    ?>
    <div class="pe-login-container">
        <div class="pe-login-card">
            <h2 class="pe-login-title"><?php esc_html_e('Iniciar sesión', 'portal-embajadores'); ?></h2>
            <p class="pe-login-subtitle"><?php esc_html_e('Accede con tu cuenta de creador', 'portal-embajadores'); ?></p>
            <div class="pe-social-login-buttons">
                <a href="<?php echo esc_url(function_exists('portal_embajadores_get_google_login_url') ? portal_embajadores_get_google_login_url() : '#'); ?>" class="pe-social-button google">
                    <span class="pe-social-icon"><svg viewBox="0 0 24 24"><g><path d="M22.56,12.25c0-.78-0.07-1.53-0.2-2.25H12v4.26h5.92c-0.26,1.37-1.04,2.53-2.21,3.31v2.77h3.57 C20.48,18.27,22.56,15.5,22.56,12.25z" fill="#4285F4"></path><path d="M12,23c2.97,0,5.46-0.98,7.28-2.66l-3.57-2.77c-0.98,0.66-2.23,1.06-3.71,1.06c-2.86,0-5.29-1.93-6.16-4.53H2.18v2.84 C3.99,20.53,7.7,23,12,23z" fill="#34A853"></path><path d="M5.84,14.09c-0.22-0.66-0.35-1.36-0.35-2.09s0.13-1.43,0.35-2.09V7.07H2.18C1.43,8.55,1,10.22,1,12s0.43,3.45,1.18,4.93 L5.84,14.09z" fill="#FBBC05"></path><path d="M12,5.38c1.62,0,3.06,0.56,4.21,1.64l3.15-3.15C17.45,2.09,14.97,1,12,1C7.7,1,3.99,3.47,2.18,7.07l3.66,2.84 C6.7,7.31,9.14,5.38,12,5.38z" fill="#EA4335"></path></g></svg></span>
                    <span class="pe-social-text"><?php esc_html_e('Acceder con Google', 'portal-embajadores'); ?></span>
                    <span class="pe-arrow-icon">&rarr;</span>
                </a>
                <a href="<?php echo esc_url(function_exists('portal_embajadores_get_twitch_login_url') ? portal_embajadores_get_twitch_login_url() : '#'); ?>" class="pe-social-button twitch">
                    <span class="pe-social-icon"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.571 4.714h1.715v5.143H11.57zm4.571 0H17.86v5.143h-1.714zM6 0L1.714 4.286v15.428h5.143V24l4.286-4.286h3.428L24 16.286V0zm16.286 15.428l-3.428 3.429h-3.429l-3 3v-3H6.857V1.714h15.43z" fill="currentColor"/></svg></span>
                    <span class="pe-social-text"><?php esc_html_e('Acceder con Twitch', 'portal-embajadores'); ?></span>
                    <span class="pe-arrow-icon">&rarr;</span>
                </a>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('portal_embajadores_login', 'portal_embajadores_login_buttons_shortcode');