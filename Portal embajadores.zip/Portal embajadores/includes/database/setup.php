<?php
/**
 * Configuración de la base de datos para el Portal de Embajadores.
 * Se ejecuta en la activación del plugin.
 * VERSIÓN CORREGIDA
 */

if (!defined('ABSPATH')) {
    exit; // Salir si se accede directamente.
}

/**
 * Crea o actualiza las tablas necesarias para el plugin.
 * Utiliza dbDelta para asegurar que las tablas tengan la estructura correcta.
 */
function portal_embajadores_realizar_setup_database() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php'); // Necesario para dbDelta

    // --- Tabla de Embajadores ---
    $table_name_embajadores = $wpdb->prefix . 'portal_embajadores';
    $sql_embajadores = "CREATE TABLE {$table_name_embajadores} (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id bigint(20) UNSIGNED NOT NULL,
        sku varchar(255) DEFAULT '' NOT NULL,
        cupon varchar(100) DEFAULT '' NOT NULL,
        porcentaje decimal(5,2) UNSIGNED DEFAULT '0.00' NOT NULL,
        pagado tinyint(1) DEFAULT 0 NOT NULL,
        fecha_registro datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY user_id_unique (user_id),
        KEY cupon (cupon)
    ) {$charset_collate};";
    dbDelta($sql_embajadores);

    // --- Tabla de Alertas OBS ---
    $table_name_alertas = $wpdb->prefix . 'portal_alertas';
    $sql_alertas = "CREATE TABLE {$table_name_alertas} (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        embajador_id bigint(20) UNSIGNED NOT NULL,
        tipo_alerta varchar(50) DEFAULT 'venta' NOT NULL,
        media_url text,
        audio_url text,
        mensaje text,
        duracion int(10) UNSIGNED DEFAULT 8 NOT NULL,
        posicion varchar(50) DEFAULT 'center' NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY embajador_tipo_alerta (embajador_id, tipo_alerta)
    ) {$charset_collate};";
    dbDelta($sql_alertas);

    // --- Tabla de Correos Autorizados ---
    $table_name_correos = $wpdb->prefix . 'portal_embajadores_correos';
    $sql_correos = "CREATE TABLE {$table_name_correos} (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        email varchar(255) NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY email (email)
    ) {$charset_collate};";
    dbDelta($sql_correos);

    // --- Tabla de Ventas (CON LA SINTAXIS CORREGIDA) ---
    $table_name_ventas = $wpdb->prefix . 'portal_embajadores_ventas';
    $sql_ventas = "CREATE TABLE {$table_name_ventas} (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        embajador_id bigint(20) UNSIGNED NOT NULL,
        order_id bigint(20) UNSIGNED DEFAULT 0 NOT NULL,
        fecha datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        sku_producto varchar(255) DEFAULT '' NOT NULL,
        cupon_usado varchar(100) DEFAULT '' NOT NULL,
        importe_total_venta decimal(10,2) DEFAULT '0.00' NOT NULL,
        importe_comision decimal(10,2) DEFAULT '0.00' NOT NULL,
        alerta_mostrada tinyint(1) DEFAULT 0 NOT NULL,
        PRIMARY KEY  (id),
        KEY embajador_id (embajador_id),
        KEY order_id (order_id),
        KEY idx_alerta_check (embajador_id, alerta_mostrada, fecha)
    ) {$charset_collate};";
    dbDelta($sql_ventas);

    // Guardar la versión de la base de datos para futuras actualizaciones
    update_option('portal_embajadores_db_version', '1.1.1'); // Usa la versión que corresponda
}