<?php
/**
 * Shortcode para el Panel del Embajador.
 * Muestra información del embajador, estadísticas de ventas y configuración de alertas OBS.
 * VERSIÓN LIMPIA con CSS y JS en archivos externos.
 */

if (!defined('ABSPATH')) {
    exit; // Salir si se accede directamente.
}

/**
 * Maneja el guardado de la configuración de alertas OBS para el embajador.
 */
function portal_embajadores_handle_save_alert_config() {
    if (!is_user_logged_in() || !isset($_POST['save_alert_config_submit'])) {
        return;
    }
    if (isset($_POST['portal_embajador_save_alert_nonce'])) {
        if (!wp_verify_nonce($_POST['portal_embajador_save_alert_nonce'], 'portal_embajador_save_alert_action')) {
            wp_safe_redirect(add_query_arg('pe_alert_status', 'nonce_error', wp_get_referer()));
            exit;
        }

        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');

        global $wpdb;
        $user_id = get_current_user_id();

        $media_url = '';
        if (!empty($_FILES['media_file']['name'])) {
            $upload = wp_handle_upload($_FILES['media_file'], ['test_form' => false]);
            $media_url = $upload['url'] ?? '';
        } elseif (!empty($_POST['media_url'])) {
            $media_url = esc_url_raw(trim($_POST['media_url']));
        }
        
        $audio_url = '';
        if (!empty($_FILES['audio_file']['name'])) {
            $upload = wp_handle_upload($_FILES['audio_file'], ['test_form' => false]);
            $audio_url = $upload['url'] ?? '';
        } elseif (!empty($_POST['audio_url'])) {
            $audio_url = esc_url_raw(trim($_POST['audio_url']));
        }
        
        $alerta_actual = $wpdb->get_row($wpdb->prepare("SELECT media_url, audio_url FROM {$wpdb->prefix}portal_alertas WHERE embajador_id = %d AND tipo_alerta = %s", $user_id, 'venta'));
        if (empty($media_url) && !empty($alerta_actual->media_url)) {
           $media_url = $alerta_actual->media_url;
        }
        if (empty($audio_url) && !empty($alerta_actual->audio_url)) {
           $audio_url = $alerta_actual->audio_url;
        }

        if (empty($media_url)) {
            wp_safe_redirect(add_query_arg('pe_alert_status', 'media_required_error', wp_get_referer()));
            exit;
        }

        $mensaje    = !empty($_POST['mensaje'])    ? sanitize_text_field(trim($_POST['mensaje']))    : __('¡Nueva Venta!', 'portal-embajadores');
        $duracion   = isset($_POST['duracion'])    ? max(1, min(60, intval($_POST['duracion'])))    : 8;
        $posiciones = ['center','top-left','top-center','top-right','middle-left','middle-right','bottom-left','bottom-center','bottom-right'];
        $posicion   = in_array($_POST['posicion'] ?? '', $posiciones, true) ? sanitize_key($_POST['posicion']) : 'center';

        $wpdb->replace(
            "{$wpdb->prefix}portal_alertas",
            [
                'embajador_id' => $user_id,
                'tipo_alerta'  => 'venta',
                'media_url'    => $media_url,
                'audio_url'    => $audio_url,
                'mensaje'      => $mensaje,
                'duracion'     => $duracion,
                'posicion'     => $posicion,
            ],
            ['%d','%s','%s','%s','%s','%d','%s']
        );

        wp_safe_redirect(add_query_arg('pe_alert_status', 'success', wp_get_referer()));
        exit;
    }
}
add_action('template_redirect', 'portal_embajadores_handle_save_alert_config');


/**
 * Genera el contenido del panel del embajador.
 */
function portal_embajador_render_panel_shortcode_content() {
    if (!is_user_logged_in()) {
        return '<p>' . esc_html__('Debes iniciar sesión para ver esta página.', 'portal-embajadores') . '</p>';
    }

    global $wpdb;
    $current_user = wp_get_current_user();
    if (!in_array('embajador', (array) $current_user->roles, true)) {
        return '<p>' . esc_html__('No tienes el rol de embajador. Contacta con el administrador si crees que esto es un error.', 'portal-embajadores') . '</p>';
    }
    $user_id = $current_user->ID;

    $embajador = $wpdb->get_row($wpdb->prepare("SELECT sku, cupon, porcentaje FROM {$wpdb->prefix}portal_embajadores WHERE user_id = %d", $user_id));
    $inicio_default = date('Y-m-01');
    $fin_default    = date('Y-m-t');
    $fecha_inicio   = sanitize_text_field($_GET['pe_stat_inicio'] ?? $inicio_default);
    $fecha_fin      = sanitize_text_field($_GET['pe_stat_fin'] ?? $fin_default);
    $fi = DateTime::createFromFormat('Y-m-d', $fecha_inicio);
    $ff = DateTime::createFromFormat('Y-m-d', $fecha_fin);
    if (!$fi || !$ff || $ff < $fi) {
        $fecha_inicio = $inicio_default;
        $fecha_fin    = $fin_default;
    }
    $ventas = $wpdb->get_results($wpdb->prepare("SELECT fecha, sku_producto, cupon_usado, importe_total_venta, importe_comision FROM {$wpdb->prefix}portal_embajadores_ventas WHERE embajador_id = %d AND DATE(fecha) BETWEEN %s AND %s ORDER BY fecha DESC", $user_id, $fecha_inicio, $fecha_fin));
    
    // Usando funciones anónimas estándar para máxima compatibilidad de PHP.
    $tot_ventas = array_reduce($ventas, function($sum, $v) { return $sum + floatval($v->importe_total_venta); }, 0);
    $tot_comis  = array_reduce($ventas, function($sum, $v) { return $sum + floatval($v->importe_comision); }, 0);
    
    $alerta = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}portal_alertas WHERE embajador_id = %d AND tipo_alerta = %s", $user_id, 'venta'));
    if (!$alerta) {
        $alerta = (object)['media_url'=>'','audio_url'=>'','mensaje'=>__('¡Nueva Venta!', 'portal-embajadores'),'duracion'=>8,'posicion'=>'center'];
    }

    ob_start();
    ?>
    <div class="embajador-panel">
        <h2><?php esc_html_e('Perfil Embajador', 'portal-embajadores'); ?></h2>
        
        <?php if (isset($_GET['pe_alert_status'])): ?>
            <div class="pe-notice <?php echo esc_attr($_GET['pe_alert_status']==='success' ? 'success' : 'error'); ?>">
                <p><?php echo esc_html($_GET['pe_alert_status']==='success' ? __('Configuración guardada correctamente.', 'portal-embajadores') : __('Error al guardar la configuración.', 'portal-embajadores')); ?></p>
            </div>
        <?php endif; ?>

        <div class="panel-card">
            <h3>🔗 <?php esc_html_e('Enlace OBS', 'portal-embajadores'); ?></h3>
            <div class="obs-link-wrapper">
                <input id="obs-link-input" readonly value="<?php echo esc_url(home_url("/?obs_alert_uid={$user_id}&alert_type=venta")); ?>">
                <button class="embajador-button btn-secondary" id="copy-obs-link-btn"><?php esc_html_e('Copiar', 'portal-embajadores'); ?></button>
            </div>
        </div>

        <div class="panel-main-grid">
            <div class="panel-card">
                <h3>📊 <?php esc_html_e('Estadísticas', 'portal-embajadores'); ?></h3>
                <form method="get" class="stats-form">
                    <div>
                        <label for="pe_stat_inicio"><?php esc_html_e('Desde:', 'portal-embajadores'); ?></label>
                        <input type="date" id="pe_stat_inicio" name="pe_stat_inicio" value="<?php echo esc_attr($fecha_inicio); ?>">
                    </div>
                    <div>
                        <label for="pe_stat_fin"><?php esc_html_e('Hasta:', 'portal-embajadores'); ?></label>
                        <input type="date" id="pe_stat_fin" name="pe_stat_fin" value="<?php echo esc_attr($fecha_fin); ?>">
                    </div>
                    <button type="submit" class="embajador-button btn-primary" style="align-self: end;"><?php esc_html_e('Filtrar', 'portal-embajadores'); ?></button>
                </form>

                <div class="stats-table-wrapper">
                    <table class="stats-table">
                        <thead>
                            <tr>
                                <th><?php esc_html_e('Fecha', 'portal-embajadores'); ?></th>
                                <th><?php esc_html_e('SKU', 'portal-embajadores'); ?></th>
                                <th><?php esc_html_e('Cupón', 'portal-embajadores'); ?></th>
                                <th style="text-align:right;"><?php esc_html_e('Venta (€)', 'portal-embajadores'); ?></th>
                                <th style="text-align:right;"><?php esc_html_e('Comisión (€)', 'portal-embajadores'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($ventas)): foreach ($ventas as $v): ?>
                                <tr>
                                    <td><?php echo esc_html(wp_date(get_option('date_format'), strtotime($v->fecha))); ?></td>
                                    <td><?php echo esc_html($v->sku_producto ?: 'N/A'); ?></td>
                                    <td><?php echo esc_html($v->cupon_usado ?: 'N/A'); ?></td>
                                    <td style="text-align:right;"><?php echo esc_html(number_format_i18n(floatval($v->importe_total_venta), 2)); ?></td>
                                    <td style="text-align:right;"><?php echo esc_html(number_format_i18n(floatval($v->importe_comision), 2)); ?></td>
                                </tr>
                            <?php endforeach; else: ?>
                                <tr><td colspan="5" style="text-align:center; padding: 2rem;"><?php esc_html_e('No hay ventas en este periodo.', 'portal-embajadores'); ?></td></tr>
                            <?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="3" style="text-align:right;"><?php esc_html_e('Totales:', 'portal-embajadores'); ?></th>
                                <th style="text-align:right;"><?php echo esc_html(number_format_i18n($tot_ventas, 2)); ?>€</th>
                                <th style="text-align:right;"><?php echo esc_html(number_format_i18n($tot_comis, 2)); ?>€</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>

            <div class="panel-card">
                <h3>⚙️ <?php esc_html_e('Configuración de Alerta OBS', 'portal-embajadores'); ?></h3>
                <form id="alert-config-form" method="post" enctype="multipart/form-data">
                    <?php wp_nonce_field('portal_embajador_save_alert_action','portal_embajador_save_alert_nonce'); ?>
                    
                    <div class="form-group">
                        <label for="media_url"><?php esc_html_e('URL Imagen/Vídeo', 'portal-embajadores'); ?></label>
                        <input id="media_url" type="url" name="media_url" value="<?php echo esc_attr($alerta->media_url); ?>" placeholder="https://ejemplo.com/alerta.gif">
                        <div class="upload-or"><?php esc_html_e('o', 'portal-embajadores'); ?></div>
                        <label for="media_file"><?php esc_html_e('Subir un archivo nuevo', 'portal-embajadores'); ?></label>
                        <input id="media_file" type="file" name="media_file" accept="image/*,video/*">
                    </div>
                    
                    <hr style="border:none; border-top:1px solid var(--medium-gray); margin: 2rem 0;">

                    <div class="form-group">
                        <label for="audio_url"><?php esc_html_e('URL Audio', 'portal-embajadores'); ?></label>
                        <input id="audio_url" type="url" name="audio_url" value="<?php echo esc_attr($alerta->audio_url); ?>" placeholder="https://ejemplo.com/sonido.mp3">
                        <div class="upload-or"><?php esc_html_e('o', 'portal-embajadores'); ?></div>
                        <label for="audio_file"><?php esc_html_e('Subir un archivo de audio', 'portal-embajadores'); ?></label>
                        <input id="audio_file" type="file" name="audio_file" accept="audio/*">
                    </div>
                    
                    <hr style="border:none; border-top:1px solid var(--medium-gray); margin: 2rem 0;">

                    <div class="form-group">
                        <label for="mensaje"><?php esc_html_e('Mensaje de Alerta', 'portal-embajadores'); ?></label>
                        <input id="mensaje" type="text" name="mensaje" value="<?php echo esc_attr($alerta->mensaje); ?>">
                    </div>

                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem;">
                        <div class="form-group">
                            <label for="duracion"><?php esc_html_e('Duración (segundos)', 'portal-embajadores'); ?></label>
                            <input id="duracion" type="number" name="duracion" min="1" max="60" value="<?php echo esc_attr($alerta->duracion); ?>">
                        </div>
                        <div class="form-group">
                            <label for="posicion"><?php esc_html_e('Posición', 'portal-embajadores'); ?></label>
                            <select id="posicion" name="posicion">
                                <?php
                                $pos_map = ['center'=>'Centro','top-left'=>'Arriba Izquierda','top-center'=>'Arriba Centro','top-right'=>'Arriba Derecha','middle-left'=>'Medio Izquierda','middle-right'=>'Medio Derecha','bottom-left'=>'Abajo Izquierda','bottom-center'=>'Abajo Centro','bottom-right'=>'Abajo Derecha'];
                                foreach ($pos_map as $val => $lab) {
                                    printf('<option value="%s"%s>%s</option>', esc_attr($val), selected($alerta->posicion, $val, false), esc_html__($lab, 'portal-embajadores'));
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" name="save_alert_config_submit" class="embajador-button btn-primary"><?php esc_html_e('Guardar Configuración', 'portal-embajadores'); ?></button>
                        <button type="button" id="test-alert-btn" class="embajador-button btn-secondary"><?php esc_html_e('Probar Alerta', 'portal-embajadores'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('portal_embajador_panel', 'portal_embajador_render_panel_shortcode_content');