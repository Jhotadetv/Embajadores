<?php
/**
 * Endpoint para las Alertas OBS del Portal de Embajadores.
 * VERSIÓN CORREGIDA Y MEJORADA
 */

if (!defined('ABSPATH')) {
    exit; // Salir si se accede directamente.
}

add_action('template_redirect', 'portal_embajador_obs_alert_endpoint_handler');

function portal_embajador_obs_alert_endpoint_handler() {
    if (!isset($_GET['obs_alert_uid'])) {
        return;
    }

    $embajador_user_id = intval($_GET['obs_alert_uid']);
    if ($embajador_user_id <= 0) {
        wp_die('ID de embajador no válido.', 'Error de Alerta OBS', ['response' => 400]);
        exit;
    }

    global $wpdb;
    $table_alertas = $wpdb->prefix . 'portal_alertas';
    $tipo_alerta_deseada = isset($_GET['alert_type']) ? sanitize_key($_GET['alert_type']) : 'venta';

    $alerta_config = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table_alertas} WHERE embajador_id = %d AND tipo_alerta = %s ORDER BY id DESC LIMIT 1",
        $embajador_user_id,
        $tipo_alerta_deseada
    ));

    if (!$alerta_config) {
        $alerta_config = (object) [
            'media_url' => '',
            'audio_url' => '',
            'mensaje'   => __('¡Nueva Venta!', 'portal-embajadores'),
            'duracion'  => 8,
            'posicion'  => 'center',
        ];
    }

    $posiciones_css_map = [
        'center'       => 'top: 50%; left: 50%; transform: translate(-50%, -50%);',
        'top-left'     => 'top: 20px; left: 20px;',
        'top-center'   => 'top: 20px; left: 50%; transform: translateX(-50%);',
        'top-right'    => 'top: 20px; right: 20px;',
        'middle-left'  => 'top: 50%; left: 20px; transform: translateY(-50%);',
        'middle-right' => 'top: 50%; right: 20px; transform: translateY(-50%);',
        'bottom-left'  => 'bottom: 20px; left: 20px;',
        'bottom-center'=> 'bottom: 20px; left: 50%; transform: translateX(-50%);',
        'bottom-right' => 'bottom: 20px; right: 20px;',
    ];
    $posicion_css = $posiciones_css_map[$alerta_config->posicion] ?? $posiciones_css_map['center'];

    $duracion_segundos   = max(1, intval($alerta_config->duracion));
    $mensaje_plantilla   = esc_html($alerta_config->mensaje);
    $media_url_sanitized = esc_url($alerta_config->media_url);
    $audio_url_sanitized = esc_url($alerta_config->audio_url);

    $is_video = false;
    if ($media_url_sanitized) {
        $ext = strtolower(pathinfo($media_url_sanitized, PATHINFO_EXTENSION));
        $is_video = in_array($ext, ['mp4','webm','ogg'], true);
    }

    header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
    header("Pragma: no-cache");
    header("Content-Type: text/html; charset=UTF-8");
    ?>
    <!DOCTYPE html>
    <html lang="<?php echo esc_attr(get_bloginfo('language')); ?>">
    <head>
        <meta charset="<?php echo esc_attr(get_bloginfo('charset')); ?>">
        <title><?php echo esc_html__('Alerta OBS', 'portal-embajadores'); ?></title>
        <style>
            body { background: transparent; margin:0; padding:0; overflow:hidden; }
            .alerta-obs-container { position: fixed; <?php echo esc_attr($posicion_css); ?> z-index: 9999; display: none; text-align: center; }
            .alerta-obs-container img, .alerta-obs-container video { max-width: 80vw; max-height: 80vh; margin-bottom: 10px; }
            .mensaje-alerta { font-size: 48px; color: white; text-shadow: 3px 3px 6px black; font-weight: bold; font-family: sans-serif; }
            .fade-in { animation: fadeIn 1s forwards; }
            .fade-out { animation: fadeOut 1s forwards; }
            @keyframes fadeIn { from {opacity:0;} to {opacity:1;} }
            @keyframes fadeOut { from {opacity:1;} to {opacity:0;} }
        </style>
    </head>
    <body>
        <div class="alerta-obs-container" id="alertaObsContainer">
            <?php if ($media_url_sanitized): ?>
                <?php if ($is_video): ?>
                    <video id="alertaMediaVideo" src="<?php echo $media_url_sanitized; ?>" muted playsinline loop></video>
                <?php else: ?>
                    <img id="alertaMediaImage" src="<?php echo $media_url_sanitized; ?>" alt="<?php echo esc_attr__('Alerta Visual', 'portal-embajadores'); ?>">
                <?php endif; ?>
            <?php endif; ?>
            <div class="mensaje-alerta" id="alertaMensaje"></div>
            <?php if ($audio_url_sanitized): ?>
                <audio id="alertaAudio" src="<?php echo $audio_url_sanitized; ?>" preload="auto"></audio>
            <?php endif; ?>
        </div>

        <script>
            const cont = document.getElementById('alertaObsContainer');
            const msgEl = document.getElementById('alertaMensaje');
            const vid = document.getElementById('alertaMediaVideo');
            const aud = document.getElementById('alertaAudio');
            const dur = <?php echo $duracion_segundos; ?> * 1000;
            const POLLING_INTERVAL = 10000; // 10 segundos
            let isVisible = false;

            function showAlert(data) {
                if (isVisible) return;

                let text = "<?php echo $mensaje_plantilla; ?>";
                for (let key in data) {
                    text = text.replace(new RegExp('{' + key + '}', 'g'), data[key]);
                }
                
                msgEl.textContent = text;
                cont.style.display = 'block';
                cont.classList.remove('fade-out');
                cont.classList.add('fade-in');
                isVisible = true;

                if (vid) vid.play().catch(e => console.error("Video play failed:", e));
                if (aud) aud.play().catch(e => console.error("Audio play failed:", e));

                setTimeout(() => {
                    cont.classList.remove('fade-in');
                    cont.classList.add('fade-out');
                    setTimeout(() => {
                        cont.style.display = 'none';
                        isVisible = false;
                        if (aud) aud.pause();
                        // --- MEJORA 2: Pausar el vídeo al ocultar ---
                        if (vid) vid.pause();
                    }, 1000); // Duración del fade-out
                }, dur);
            }

            async function checkForAlerts() {
                try {
                    // --- ERROR CRÍTICO CORREGIDO: URL de la API ajustada ---
                    const apiUrl = '<?php echo esc_url_raw(get_rest_url(null, "portal_embajadores/v1/check_new_alert/{$embajador_user_id}")); ?>';
                    const response = await fetch(apiUrl, { cache: 'no-store' });
                    
                    if (response.ok) {
                        const json = await response.json();
                        if (json.trigger_alert) {
                            showAlert(json.alert_data || {});
                        }
                    }
                } catch (e) {
                    console.error("Error checking for alerts:", e);
                } finally {
                    // --- MEJORA 1: Usar setTimeout para el siguiente chequeo ---
                    setTimeout(checkForAlerts, POLLING_INTERVAL);
                }
            }

            // Iniciar el primer chequeo
            checkForAlerts();
        </script>
    </body>
    </html>
    <?php
    exit;
}