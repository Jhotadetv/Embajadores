<?php
/**
 * Plugin Name: Portal Embajadores
 * Plugin URI: https://example.com/portal-embajadores
 * Description: Plugin universal para la gestión de embajadores con integración OAuth, alertas OBS y control de comisiones y pagos.
 * Version: 1.2.0
 * Author: Tu Nombre
 * Author URI: https://example.com
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: portal-embajadores
 * Domain Path: /languages
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit; // Salir si se accede directamente.
}

// Cargar autoload de Composer ANTES de nada. Es una dependencia crítica.
$composer_autoload = __DIR__ . '/vendor/autoload.php';
if (!file_exists($composer_autoload)) {
    add_action('admin_notices', function() {
        echo '<div class="error"><p>';
        echo esc_html__('El plugin Portal Embajadores no puede funcionar porque faltan dependencias críticas (Composer). Por favor, ejecuta "composer install" en el directorio del plugin o descarga la versión completa.', 'portal-embajadores');
        echo '</p></div>';
    });
    return; // Detener la carga del plugin por completo.
}
require_once $composer_autoload;


final class Portal_Embajadores {

    /**
     * Versión del plugin.
     * @var string
     */
    const VERSION = '1.2.0';

    /**
     * Instancia única de la clase.
     * @var Portal_Embajadores|null
     */
    private static $instance = null;

    /**
     * Constructor principal.
     */
    private function __construct() {
        $this->define_constants();
        $this->load_dependencies();
        $this->init_hooks();
    }

    /**
     * Asegura que solo haya una instancia de la clase (Patrón Singleton).
     */
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Definir constantes del plugin.
     */
    private function define_constants() {
        define('PORTAL_EMBAJADORES_VERSION', self::VERSION);
        define('PORTAL_EMBAJADORES_PLUGIN_FILE', __FILE__);
        define('PORTAL_EMBAJADORES_PLUGIN_DIR', plugin_dir_path(PORTAL_EMBAJADORES_PLUGIN_FILE));
        define('PORTAL_EMBAJADORES_PLUGIN_URL', plugin_dir_url(PORTAL_EMBAJADORES_PLUGIN_FILE));
    }

    /**
     * Cargar todos los archivos necesarios.
     */
    private function load_dependencies() {
        // Setup de la base de datos (contiene la función que se llamará en la activación)
        require_once PORTAL_EMBAJADORES_PLUGIN_DIR . 'includes/database/setup.php';
        
        // Funciones generales y hooks principales
        require_once PORTAL_EMBAJADORES_PLUGIN_DIR . 'includes/functions.php';

        // Lógica de Administración
        if (is_admin()) {
            require_once PORTAL_EMBAJADORES_PLUGIN_DIR . 'includes/admin/admin-menu.php';
        }

        // Lógica del Frontend
        require_once PORTAL_EMBAJADORES_PLUGIN_DIR . 'includes/public/obs-alerts.php';
        require_once PORTAL_EMBAJADORES_PLUGIN_DIR . 'includes/public/embajador-panel.php';

        // Integraciones OAuth
        require_once PORTAL_EMBAJADORES_PLUGIN_DIR . 'includes/integrations/oauth-google.php';
        require_once PORTAL_EMBAJADORES_PLUGIN_DIR . 'includes/integrations/oauth-twitch.php';
    }

    /**
     * Registrar todos los hooks de WordPress.
     */
    private function init_hooks() {
        // Hooks de ciclo de vida del plugin
        register_activation_hook(PORTAL_EMBAJADORES_PLUGIN_FILE, [$this, 'activate']);
        // register_deactivation_hook(PORTAL_EMBAJADORES_PLUGIN_FILE, [$this, 'deactivate']); // Descomentar si se necesita
        
        // Carga de assets (CSS/JS) y textdomain
        add_action('plugins_loaded', [$this, 'load_textdomain']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_assets']);
        
        // Inicialización de funcionalidades
        add_action('init', [$this, 'create_ambassador_role']);
        
        // Enlaces en la página de plugins
        add_filter('plugin_action_links_' . plugin_basename(PORTAL_EMBAJADORES_PLUGIN_FILE), [$this, 'plugin_action_links']);
    }

    /**
     * Se ejecuta en la activación del plugin.
     */
    public function activate() {
        ob_start();
        portal_embajadores_realizar_setup_database(); // Llama a la función del archivo setup.php
        $this->create_ambassador_role(); // Asegurarse de que el rol existe al activar
        flush_rewrite_rules(); // Buena práctica al activar
        ob_end_clean();
    }

    /**
     * Cargar el text domain para la internacionalización.
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'portal-embajadores',
            false,
            dirname(plugin_basename(PORTAL_EMBAJADORES_PLUGIN_FILE)) . '/languages/'
        );
    }
    
    /**
     * Encolar scripts y estilos para el frontend.
     */
    public function enqueue_frontend_assets() {
        global $post;
        // Cargar los assets solo en la página que contiene el shortcode del panel para optimizar.
        if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'portal_embajador_panel')) {
            wp_enqueue_style(
                'portal-embajadores-panel-css',
                PORTAL_EMBAJADORES_PLUGIN_URL . 'assets/css/portal.css',
                [],
                PORTAL_EMBAJADORES_VERSION
            );
            wp_enqueue_script(
                'portal-embajadores-panel-js',
                PORTAL_EMBAJADORES_PLUGIN_URL . 'assets/js/portal.js',
                [],
                PORTAL_EMBAJADORES_VERSION,
                true // Cargar en el footer
            );
        }
    }

    /**
     * Registrar el rol de 'Embajador' si no existe.
     */
    public function create_ambassador_role() {
        if (!get_role('embajador')) {
            add_role(
                'embajador',
                __('Embajador', 'portal-embajadores'),
                ['read' => true]
            );
        }
    }

    /**
     * Añade un enlace de "Ajustes" a la lista de plugins.
     */
    public function plugin_action_links($links) {
        $settings_link = '<a href="' . esc_url(admin_url('admin.php?page=settings-embajadores')) . '">' . esc_html__('Ajustes', 'portal-embajadores') . '</a>';
        array_unshift($links, $settings_link);
        return $links;
    }
}

/**
 * Función de inicialización para arrancar el plugin.
 */
function portal_embajadores_init() {
    Portal_Embajadores::get_instance();
}
// Arrancar el plugin.
portal_embajadores_init();