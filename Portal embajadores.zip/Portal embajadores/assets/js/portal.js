document.addEventListener('DOMContentLoaded', function() {
    // --- Lógica para el botón de copiar ---
    const copyBtn = document.getElementById('copy-obs-link-btn');
    if (copyBtn) {
        copyBtn.addEventListener('click', function() {
            const input = document.getElementById('obs-link-input');
            if (navigator.clipboard) {
                navigator.clipboard.writeText(input.value).then(function() {
                    const originalText = copyBtn.textContent;
                    copyBtn.textContent = '¡Copiado!';
                    copyBtn.style.backgroundColor = '#28a745';
                    setTimeout(() => {
                        copyBtn.textContent = originalText;
                        copyBtn.style.backgroundColor = '';
                    }, 2000);
                });
            }
        });
    }
    
    // --- Lógica para el botón de prueba ---
    const testBtn = document.getElementById('test-alert-btn');
    if (testBtn) {
        testBtn.addEventListener('click', function() {
            // Leer valores del formulario
            const mediaUrl = document.getElementById('media_url').value;
            const audioUrl = document.getElementById('audio_url').value;
            const message = document.getElementById('mensaje').value.replace('{producto}', 'Producto de Prueba').replace('{comision}', '12.34€');
            const duration = parseInt(document.getElementById('duracion').value, 10) * 1000;
            const position = document.getElementById('posicion').value;
            const mediaFile = document.getElementById('media_file').files[0];
            const audioFile = document.getElementById('audio_file').files[0];

            if (!mediaUrl && !mediaFile) {
                alert('Por favor, introduce una URL de Imagen/Vídeo o selecciona un archivo para probar la alerta.');
                return;
            }
            
            let finalMediaUrl = mediaUrl;
            if (mediaFile) {
                finalMediaUrl = URL.createObjectURL(mediaFile);
            }
            
            let finalAudioUrl = audioUrl;
            if (audioFile) {
                finalAudioUrl = URL.createObjectURL(audioFile);
            }

            // Crear el overlay de la alerta
            const overlay = document.createElement('div');
            overlay.style.position = 'fixed';
            overlay.style.top = '0';
            overlay.style.left = '0';
            overlay.style.width = '100vw';
            overlay.style.height = '100vh';
            overlay.style.zIndex = '99999';
            overlay.style.display = 'flex';
            
            // Aplicar posicionamiento
            const positionStyles = {
                'center': { justifyContent: 'center', alignItems: 'center' },
                'top-left': { justifyContent: 'flex-start', alignItems: 'flex-start' },
                'top-center': { justifyContent: 'center', alignItems: 'flex-start' },
                'top-right': { justifyContent: 'flex-end', alignItems: 'flex-start' },
                'middle-left': { justifyContent: 'flex-start', alignItems: 'center' },
                'middle-right': { justifyContent: 'flex-end', alignItems: 'center' },
                'bottom-left': { justifyContent: 'flex-start', alignItems: 'flex-end' },
                'bottom-center': { justifyContent: 'center', alignItems: 'flex-end' },
                'bottom-right': { justifyContent: 'flex-end', alignItems: 'flex-end' },
            };
            Object.assign(overlay.style, positionStyles[position]);
            
            const container = document.createElement('div');
            container.style.textAlign = 'center';
            container.style.padding = '20px';
            
            let mediaElement;
            const isImage = finalMediaUrl.match(/\.(jpeg|jpg|gif|png|svg|webp)$/i) || (mediaFile && mediaFile.type.startsWith('image/'));
            
            if (isImage) {
                mediaElement = document.createElement('img');
            } else {
                mediaElement = document.createElement('video');
                mediaElement.autoplay = true;
                mediaElement.muted = true;
                mediaElement.loop = true;
            }
            mediaElement.src = finalMediaUrl;
            mediaElement.style.maxWidth = '80vw';
            mediaElement.style.maxHeight = '80vh';
            mediaElement.style.display = 'block';

            const messageElement = document.createElement('p');
            messageElement.textContent = message;
            messageElement.style.color = 'white';
            messageElement.style.fontSize = '2rem';
            messageElement.style.fontWeight = 'bold';
            messageElement.style.textShadow = '2px 2px 4px black';
            messageElement.style.marginTop = '1rem';
            
            container.appendChild(mediaElement);
            container.appendChild(messageElement);
            overlay.appendChild(container);
            document.body.appendChild(overlay);

            if (finalAudioUrl) {
                const audio = new Audio(finalAudioUrl);
                audio.play().catch(e => console.error("Error al reproducir audio:", e));
            }

            setTimeout(() => {
                if (document.body.contains(overlay)) {
                    document.body.removeChild(overlay);
                }
                if(mediaFile) URL.revokeObjectURL(finalMediaUrl);
                if(audioFile) URL.revokeObjectURL(finalAudioUrl);
            }, duration);
        });
    }
});